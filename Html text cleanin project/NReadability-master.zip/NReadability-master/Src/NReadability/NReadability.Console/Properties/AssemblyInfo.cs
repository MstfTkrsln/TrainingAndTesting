using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("NReadability.Console")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("immortal.pl")]
[assembly: AssemblyProduct("NReadability.Console")]
[assembly: AssemblyCopyright("Copyright �  2010")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("7583466f-c5dd-4a7a-ad53-706b45d0b32d")]

[assembly: AssemblyVersion("1.4.7.0")]
[assembly: AssemblyFileVersion("1.4.7.0")]
