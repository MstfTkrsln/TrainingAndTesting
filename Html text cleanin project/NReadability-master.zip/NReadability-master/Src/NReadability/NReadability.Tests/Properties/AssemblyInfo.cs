using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("NReadability.Tests")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("immortal.pl")]
[assembly: AssemblyProduct("NReadability.Tests")]
[assembly: AssemblyCopyright("Copyright �  2010")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("57668136-834a-42ab-989d-de2ff7db3d8f")]

[assembly: AssemblyVersion("1.4.7.0")]
[assembly: AssemblyFileVersion("1.4.7.0")]
