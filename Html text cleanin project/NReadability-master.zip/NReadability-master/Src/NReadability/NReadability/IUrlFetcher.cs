﻿namespace NReadability
{
  public interface IUrlFetcher
  {
    string Fetch(string url);
  }
}
