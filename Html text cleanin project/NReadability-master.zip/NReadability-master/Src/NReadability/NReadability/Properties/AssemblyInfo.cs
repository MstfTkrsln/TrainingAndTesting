using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("NReadability")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("immortal.pl")]
[assembly: AssemblyProduct("NReadability")]
[assembly: AssemblyCopyright("Copyright �  2010")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("11153417-d4e1-4ef9-aea6-1b2a75308a0e")]

[assembly: AssemblyVersion("1.4.7.0")]
[assembly: AssemblyFileVersion("1.4.7.0")]

[assembly: InternalsVisibleTo("NReadability.Tests")]
